require 'test_helper'

class WeaponTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
